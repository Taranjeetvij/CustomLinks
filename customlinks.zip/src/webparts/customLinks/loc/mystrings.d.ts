declare interface ICustomLinksWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CustomLinksWebPartStrings' {
  const strings: ICustomLinksWebPartStrings;
  export = strings;
}
