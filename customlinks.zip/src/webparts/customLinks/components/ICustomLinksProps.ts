export interface ICustomLinksProps {
  description: string;
}
